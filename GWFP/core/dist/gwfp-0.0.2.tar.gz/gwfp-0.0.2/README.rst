GWFP
====

-  GWFP is a short abbreviation for ‘Get Forgotten WIFI Password’
-  This package is made to acquire all the forgotten wifi passwords and
   related data and store it in your desired place. You can even store
   it in your pendrive. Usually, if the location and name of the file is
   not specifed, the output file containing the data will be stored in
   the downloads folder with the name ‘out.txt’.You can go full-on
   hacker mode and clone the data from a target-pc in mere seconds.

Version updates:-
=================

-  Fresh gwfp package only available for windows.

Supported devices:-
===================

-  Windows

Dependencies:-
==============

-  re(regex)

Installation:-
==============

-  Install this tool with the *pip* command ``pip install gwfp``

Usage:-
=======

-  Run the gwfp command to generate an output file containing all the
   credentials.
-  Data will be stored in the downloads folder by default (out.txt) of
   your system.
-  You can specify options like:-h : to get help.-o : to specify output
   name.-ol : to specify output location.

Developer contact:-
===================

-  Contact at raghavgohil2004@gmail.com
