
# GWFP
* GWFP is a short abbreviation for 'Get Forgotten WIFI Password'
* This tool to get forgotten wifi passwords quickly and easily.

# Version updates:-
* Fresh gwfp package only available for windows.

# Supported devices:-
* Windows

# Dependencies:-
* re(regex)

# Installation:-
* Install this tool with the *pip* command
```pip install gwfp```

# Usage:-
* Run the gwfp command to generate an output file containing all the credentials.
* View the credentials in the downloads folder of your system.

# Developer contact:-
* Contact at raghav15102004@gmail.com